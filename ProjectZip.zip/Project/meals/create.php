<?php
include "../connect.php";
date_default_timezone_set("Asia/kathmandu");

if(isset($_POST['submit'])){
  $name=$_POST['name'];
  $displayName=$_POST['displayName'];
  $now = date('Y-m-d H:i:s');

  $sql="INSERT INTO `meals`(name,display_name,created_at, updated_at) VALUES('". $name ."','". $displayName ."','". $now ."','". $now ."')";
  //echo $sql;
  $result=mysqli_query($con,$sql);
  if($result){
    echo "data inserted successfully";
  }else{
    die(mysqli_error($con));
    // echo '<pre>';
    // print_r($con);
    // echo '</pre>';
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <title>Crud operation</title>
</head>
<body>
  <div class="container my-5">
  <form method="POST">
  <div class="form-group">
    <label>Name</label>
    <input type="text" class="form-control" placeholder="Enter your name" name="name">
</div>
  <form method="POST">
  <div class="form-group">
    <label>Display Name</label>
    <input type="text" class="form-control" placeholder="Enter display name" name="displayName">
</div>
<button type="submit" class="btn btn-primary" name="submit">Save</button>
<a href="http://foodrecipesystem.pr/meals" class="btn btn-danger btn-md">Cancel</a>
</form></div>
</body>
</html>