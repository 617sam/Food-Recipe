<?php
$con=new mysqli('localhost','root','','crudoperation');
if($con){
  echo "connection successful";
}else{
  die(mysqli_error($con));
}
?>