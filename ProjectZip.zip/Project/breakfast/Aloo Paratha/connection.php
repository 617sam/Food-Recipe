<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "db_aloo";


// Create connection
$conn = mysqli_connect($servername, $username, $password, $db);
// Check connection
if ($conn) {
    echo"connected";
}else{
    echo"not connected".mysqli_connect_error();
}

?>