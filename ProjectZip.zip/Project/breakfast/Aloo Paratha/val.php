<html>
<head>
    <?php
    if(empty($_POST('S.N'))||empty($_POST('Name of Dishes')))
</head>